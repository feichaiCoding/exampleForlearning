package demo;

public class Picca extends Car {
  
   public Picca(int ID, String name, float price, int volPeople, float volGoods) {
	   setID(ID);
		setName(name);
		setPrice(price);
		setVolPeople(volPeople);
		setVolGoods(volGoods);
	}

	@Override
	public float tolVolume() {
		// TODO Auto-generated method stub
		float tol = getCarNum() * getVolGoods();
		return tol;
	}

	@Override
	public int tolPeople() {
		// TODO Auto-generated method stub
		int tol = getCarNum() * getVolPeople();
		return tol;
	}

	@Override
	public float tolPrice() {
		// TODO Auto-generated method stub
		float tol = getCarNum() * getPrice();
		return tol;
	}

}