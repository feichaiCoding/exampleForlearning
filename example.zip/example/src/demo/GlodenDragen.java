package demo;
public class GlodenDragen extends Car {

	public GlodenDragen(int ID, String name, float price, int volPeople) {
		setID(ID);
		setName(name);
		setPrice(price);
		setVolPeople(volPeople);
	}

	@Override
	public float tolVolume() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int tolPeople() {
		// TODO Auto-generated method stub
		int tol = getCarNum() * getVolPeople();
		return tol;
	}

	@Override
	public float tolPrice() {
		// TODO Auto-generated method stub
		float tol = getCarNum() * getPrice();
		return tol;
	}

}