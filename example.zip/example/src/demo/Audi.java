package demo;
public class Audi extends Car {
 
   public Audi() {}
	public Audi(int ID, String name, float price, int volPeople) {
		setID(ID);
		setName(name);
		setPrice(price);
		setVolPeople(volPeople);
	}
	
	@Override
	public float tolVolume() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public float tolPrice() {
		// TODO Auto-generated method stub
		float tol = getCarNum() * getPrice();
		return tol;
	}
	@Override
	public int tolPeople() {
		// TODO Auto-generated method stub
		int tol = getCarNum() * getVolPeople();
		return tol;
	}

}