package demo;

public class Songhuajiang extends Car {
  
   public Songhuajiang(int ID, String name, float price, float volGoods) {
	   setID(ID);
		setName(name);
		setPrice(price);
		setVolGoods(volGoods);
	}

	@Override
	public float tolVolume() {
		// TODO Auto-generated method stub
		float tol = getCarNum() * getVolGoods();
		return tol;
	}
	
	@Override
	public int tolPeople() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public float tolPrice() {
		// TODO Auto-generated method stub
		float tol = getCarNum() * getPrice();
		return tol;
	}
   

}